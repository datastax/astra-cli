# coding: utf-8
'''
UNRESTRICT

Removes restriction from a role.

Synopsis


UNRESTRICT permission_name
  ON [keyspace_name.]table_name 
  FROM role_name ; 



'''
